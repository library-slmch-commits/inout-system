<?php include '../config/db.php'; ?>
<form method='POST' action='../auth/login_process.php'>
<h2>Enterprise Login</h2>
<input name='username' placeholder='username'><br>
<input type='password' name='password' placeholder='password'><br>
<button>Login</button>
</form>
