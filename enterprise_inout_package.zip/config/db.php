<?php
session_start();

$conn = new mysqli("localhost", "libinout", "1234", "enterprise_inout");
if ($conn->connect_error) {
    die("System unavailable");
}
$conn->set_charset("utf8mb4");
?>