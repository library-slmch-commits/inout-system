ENTERPRISE INOUT SYSTEM

1. Import sql/database.sql
2. Set DB user: libinout / 1234
3. Move folder to /var/www/html/inout
4. Open http://localhost/inout/public/login.php

FEATURES:
- Secure login
- Attendance IN/OUT
- Admin report
- Audit logs
