<?php
include '../config/db.php';
if(!isset($_SESSION['uid'])) die("No access");

echo "<h2>Dashboard</h2>";
echo "<a href='attendance/checkin.php'>Check IN</a><br>";
echo "<a href='attendance/checkout.php'>Check OUT</a><br>";
echo "<a href='../auth/logout.php'>Logout</a><br>";

if($_SESSION['role']=='admin'){
    echo "<a href='reports/admin.php'>Admin Report</a>";
}
?>