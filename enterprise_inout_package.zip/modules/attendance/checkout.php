<?php
include '../../config/db.php';
$uid=$_SESSION['uid'];

$conn->query("UPDATE attendance SET check_out=NOW() WHERE user_id=$uid AND check_out IS NULL");
echo "CHECKED OUT";
?>