<?php
include '../../config/db.php';
$uid=$_SESSION['uid'];

$check=$conn->query("SELECT id FROM attendance WHERE user_id=$uid AND check_out IS NULL");

if($check->num_rows==0){
$conn->query("INSERT INTO attendance(user_id,check_in,method) VALUES ($uid,NOW(),'MANUAL')");
echo "CHECKED IN";
}else{
echo "Already IN";
}
?>