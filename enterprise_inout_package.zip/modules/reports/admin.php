<?php
include '../../config/db.php';
if($_SESSION['role']!='admin') die("Denied");

$res=$conn->query("SELECT u.name,a.check_in,a.check_out,a.method FROM attendance a JOIN users u ON u.id=a.user_id");

echo "<h2>Admin Report</h2>";

while($r=$res->fetch_assoc()){
echo $r['name']." | ".$r['check_in']." | ".$r['check_out']." | ".$r['method']."<br>";
}
?>