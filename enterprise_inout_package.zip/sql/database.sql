CREATE DATABASE enterprise_inout;
USE enterprise_inout;

CREATE TABLE users (
id INT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(50) UNIQUE,
password VARCHAR(255),
name VARCHAR(100),
role ENUM('admin','staff','student'),
status TINYINT DEFAULT 1
);

CREATE TABLE attendance (
id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT,
check_in DATETIME,
check_out DATETIME,
method VARCHAR(20)
);

CREATE TABLE audit_logs (
id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT,
action VARCHAR(255),
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
