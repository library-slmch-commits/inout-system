<?php
session_destroy();
header("Location: ../public/login.php");
?>