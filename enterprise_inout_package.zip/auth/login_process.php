<?php
include '../config/db.php';

$username=$_POST['username'];
$password=$_POST['password'];

$stmt=$conn->prepare("SELECT * FROM users WHERE username=? AND status=1");
$stmt->bind_param("s",$username);
$stmt->execute();
$user=$stmt->get_result()->fetch_assoc();

if($user && password_verify($password,$user['password'])){
    session_regenerate_id(true);
    $_SESSION['uid']=$user['id'];
    $_SESSION['role']=$user['role'];

    $conn->query("INSERT INTO audit_logs(user_id,action) VALUES ({$user['id']},'LOGIN')");

    header("Location: ../modules/dashboard.php");
}else{
    echo "Invalid login";
}
?>